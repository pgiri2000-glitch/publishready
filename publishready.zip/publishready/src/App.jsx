import { useState } from "react";

const ANTHROPIC_MODEL = "claude-sonnet-4-6";

// ── Design tokens ──────────────────────────────────────────────
// Palette: deep ink navy + aged-paper cream + gold accent
// Typography: display = Georgia serif (deliberate book feel),
//             body = system-ui, mono = for numbers/dimensions
// Signature: a "manuscript page" texture card that feels like
//            holding a real proof in your hands
const styles = {
  root: {
    minHeight: "100vh",
    background: "#0F1923",
    color: "#E8E0D0",
    fontFamily: "'Georgia', serif",
  },
  header: {
    borderBottom: "1px solid #2A3545",
    padding: "20px 32px",
    display: "flex",
    alignItems: "center",
    gap: "12px",
    background: "#0A1018",
  },
  logo: {
    fontSize: "22px",
    fontWeight: "bold",
    color: "#C9A84C",
    letterSpacing: "0.04em",
  },
  tagline: {
    fontSize: "13px",
    color: "#6B7A8D",
    fontFamily: "system-ui, sans-serif",
    marginLeft: "auto",
    fontStyle: "italic",
  },
  nav: {
    display: "flex",
    gap: "4px",
    padding: "16px 32px 0",
    borderBottom: "1px solid #1E2D3D",
  },
  tab: (active) => ({
    padding: "10px 20px",
    border: "none",
    borderBottom: active ? "2px solid #C9A84C" : "2px solid transparent",
    background: "transparent",
    color: active ? "#C9A84C" : "#6B7A8D",
    fontFamily: "system-ui, sans-serif",
    fontSize: "14px",
    fontWeight: active ? "600" : "400",
    cursor: "pointer",
    transition: "color 0.15s",
  }),
  main: {
    maxWidth: "760px",
    margin: "0 auto",
    padding: "36px 24px",
  },
  card: {
    background: "#141F2B",
    border: "1px solid #1E2D3D",
    borderRadius: "8px",
    padding: "28px",
    marginBottom: "20px",
  },
  cardTitle: {
    fontSize: "18px",
    fontWeight: "bold",
    color: "#E8E0D0",
    marginBottom: "6px",
  },
  cardDesc: {
    fontSize: "14px",
    color: "#6B7A8D",
    fontFamily: "system-ui, sans-serif",
    marginBottom: "24px",
    lineHeight: "1.5",
  },
  label: {
    display: "block",
    fontSize: "13px",
    fontFamily: "system-ui, sans-serif",
    color: "#9AAABA",
    marginBottom: "6px",
    fontWeight: "500",
  },
  input: {
    width: "100%",
    background: "#0F1923",
    border: "1px solid #2A3545",
    borderRadius: "6px",
    padding: "10px 14px",
    color: "#E8E0D0",
    fontFamily: "system-ui, sans-serif",
    fontSize: "14px",
    marginBottom: "16px",
    boxSizing: "border-box",
    outline: "none",
  },
  select: {
    width: "100%",
    background: "#0F1923",
    border: "1px solid #2A3545",
    borderRadius: "6px",
    padding: "10px 14px",
    color: "#E8E0D0",
    fontFamily: "system-ui, sans-serif",
    fontSize: "14px",
    marginBottom: "16px",
    boxSizing: "border-box",
    outline: "none",
  },
  textarea: {
    width: "100%",
    background: "#0F1923",
    border: "1px solid #2A3545",
    borderRadius: "6px",
    padding: "10px 14px",
    color: "#E8E0D0",
    fontFamily: "system-ui, sans-serif",
    fontSize: "14px",
    marginBottom: "16px",
    boxSizing: "border-box",
    outline: "none",
    resize: "vertical",
    minHeight: "100px",
  },
  row: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: "16px",
  },
  btn: {
    background: "#C9A84C",
    color: "#0A1018",
    border: "none",
    borderRadius: "6px",
    padding: "11px 24px",
    fontFamily: "system-ui, sans-serif",
    fontSize: "14px",
    fontWeight: "700",
    cursor: "pointer",
    transition: "opacity 0.15s",
  },
  btnDisabled: {
    background: "#2A3545",
    color: "#6B7A8D",
    border: "none",
    borderRadius: "6px",
    padding: "11px 24px",
    fontFamily: "system-ui, sans-serif",
    fontSize: "14px",
    fontWeight: "700",
    cursor: "not-allowed",
  },
  resultBox: {
    background: "#0A1018",
    border: "1px solid #2A3545",
    borderRadius: "6px",
    padding: "20px",
    marginTop: "20px",
  },
  resultTitle: {
    fontSize: "12px",
    fontFamily: "system-ui, sans-serif",
    color: "#C9A84C",
    textTransform: "uppercase",
    letterSpacing: "0.1em",
    marginBottom: "12px",
    fontWeight: "600",
  },
  resultText: {
    fontSize: "14px",
    fontFamily: "system-ui, sans-serif",
    color: "#C8D8E8",
    lineHeight: "1.7",
    whiteSpace: "pre-wrap",
  },
  dimGrid: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: "12px",
    marginTop: "4px",
  },
  dimCard: {
    background: "#0F1923",
    border: "1px solid #2A3545",
    borderRadius: "6px",
    padding: "14px",
  },
  dimLabel: {
    fontSize: "11px",
    fontFamily: "system-ui, sans-serif",
    color: "#6B7A8D",
    textTransform: "uppercase",
    letterSpacing: "0.08em",
    marginBottom: "4px",
  },
  dimValue: {
    fontSize: "20px",
    fontFamily: "monospace",
    color: "#C9A84C",
    fontWeight: "bold",
  },
  dimUnit: {
    fontSize: "12px",
    color: "#6B7A8D",
    marginLeft: "4px",
  },
  checklist: {
    listStyle: "none",
    padding: 0,
    margin: 0,
  },
  checkItem: (done) => ({
    display: "flex",
    alignItems: "flex-start",
    gap: "12px",
    padding: "12px 0",
    borderBottom: "1px solid #1E2D3D",
    fontFamily: "system-ui, sans-serif",
    fontSize: "14px",
    color: done ? "#6B7A8D" : "#E8E0D0",
    textDecoration: done ? "line-through" : "none",
    cursor: "pointer",
  }),
  checkBox: (done) => ({
    width: "18px",
    height: "18px",
    borderRadius: "4px",
    border: done ? "none" : "2px solid #2A3545",
    background: done ? "#C9A84C" : "transparent",
    flexShrink: 0,
    marginTop: "1px",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "11px",
    color: "#0A1018",
    fontWeight: "bold",
  }),
  spinner: {
    display: "inline-block",
    width: "14px",
    height: "14px",
    border: "2px solid #2A3545",
    borderTop: "2px solid #C9A84C",
    borderRadius: "50%",
    animation: "spin 0.8s linear infinite",
    marginRight: "8px",
    verticalAlign: "middle",
  },
  copyBtn: {
    background: "transparent",
    border: "1px solid #2A3545",
    borderRadius: "4px",
    padding: "5px 12px",
    color: "#9AAABA",
    fontFamily: "system-ui, sans-serif",
    fontSize: "12px",
    cursor: "pointer",
    marginTop: "12px",
  },
};

// ── Helpers ────────────────────────────────────────────────────
function calculateCoverDimensions({ trimW, trimH, pages, coverType }) {
  const pw = parseFloat(trimW);
  const ph = parseFloat(trimH);
  const pc = parseInt(pages);
  if (!pw || !ph || !pc) return null;

  const bleed = 0.125;
  // KDP white paper: 0.002252 in/page; cream: 0.0025 in/page
  const paperThickness = 0.002252;
  const spineWidth = coverType === "hardcover"
    ? Math.max(pc * paperThickness + 0.06, 0.25)  // hardcover adds case
    : pc * paperThickness + 0.06;

  const canvasW = pw * 2 + spineWidth + bleed * 2;
  const canvasH = ph + bleed * 2;

  const safeInset = 0.25;
  const frontSafeX = bleed + pw + spineWidth + safeInset;
  const backSafeX = bleed + safeInset;
  const safeY = bleed + safeInset;
  const safeW = pw - safeInset * 2;
  const safeH = ph - safeInset * 2;

  // pixels at 300 DPI
  const dpi = 300;
  const px = (n) => Math.round(n * dpi);

  return {
    spineWidth: spineWidth.toFixed(4),
    canvasW: canvasW.toFixed(4),
    canvasH: canvasH.toFixed(4),
    canvasWpx: px(canvasW),
    canvasHpx: px(canvasH),
    frontSafeX: frontSafeX.toFixed(3),
    backSafeX: backSafeX.toFixed(3),
    safeY: safeY.toFixed(3),
    safeW: safeW.toFixed(3),
    safeH: safeH.toFixed(3),
  };
}

async function callClaude(systemPrompt, userPrompt) {
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: ANTHROPIC_MODEL,
      max_tokens: 1000,
      system: systemPrompt,
      messages: [{ role: "user", content: userPrompt }],
    }),
  });
  const data = await response.json();
  return data.content?.[0]?.text || "No response received.";
}

// ── Tabs ───────────────────────────────────────────────────────
const TABS = [
  { id: "cover", label: "📐 Cover Studio" },
  { id: "listing", label: "✍️ Listing Writer" },
  { id: "checklist", label: "✅ Submission Coach" },
  { id: "help", label: "💬 Help" },
];

// ── Cover Studio ───────────────────────────────────────────────
function CoverStudio() {
  const [form, setForm] = useState({
    trimW: "6", trimH: "9", pages: "", coverType: "paperback",
  });
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const calculate = () => {
    setLoading(true);
    setTimeout(() => {
      const dims = calculateCoverDimensions(form);
      setResult(dims);
      setLoading(false);
    }, 300);
  };

  const ready = form.trimW && form.trimH && form.pages;

  return (
    <div>
      <div style={styles.card}>
        <div style={styles.cardTitle}>Cover Dimension Calculator</div>
        <div style={styles.cardDesc}>
          Enter your book's trim size and page count. Get exact canvas size,
          spine width, bleed, and safe zone measurements — ready for Photoshop,
          Canva, or Python/PIL.
        </div>

        <div style={styles.row}>
          <div>
            <label style={styles.label}>Trim Width (inches)</label>
            <input style={styles.input} value={form.trimW} onChange={set("trimW")} placeholder="6" />
          </div>
          <div>
            <label style={styles.label}>Trim Height (inches)</label>
            <input style={styles.input} value={form.trimH} onChange={set("trimH")} placeholder="9" />
          </div>
        </div>

        <div style={styles.row}>
          <div>
            <label style={styles.label}>Page Count</label>
            <input style={styles.input} value={form.pages} onChange={set("pages")} placeholder="250" />
          </div>
          <div>
            <label style={styles.label}>Cover Type</label>
            <select style={styles.select} value={form.coverType} onChange={set("coverType")}>
              <option value="paperback">Paperback</option>
              <option value="hardcover">Hardcover</option>
            </select>
          </div>
        </div>

        <button
          style={{
            ...(ready && !loading ? styles.btn : styles.btnDisabled),
            opacity: loading ? 0.7 : 1,
          }}
          onClick={() => ready && !loading && calculate()}
        >
          {loading ? "Calculating…" : "Calculate Dimensions"}
        </button>
      </div>

      {result && (
        <div style={styles.resultBox}>
          <div style={styles.resultTitle}>Your KDP Cover Dimensions</div>
          <div style={styles.dimGrid}>
            <div style={styles.dimCard}>
              <div style={styles.dimLabel}>Canvas Width</div>
              <div style={styles.dimValue}>{result.canvasW}<span style={styles.dimUnit}>in</span></div>
              <div style={{ ...styles.dimLabel, marginTop: "4px" }}>{result.canvasWpx} px @ 300 DPI</div>
            </div>
            <div style={styles.dimCard}>
              <div style={styles.dimLabel}>Canvas Height</div>
              <div style={styles.dimValue}>{result.canvasH}<span style={styles.dimUnit}>in</span></div>
              <div style={{ ...styles.dimLabel, marginTop: "4px" }}>{result.canvasHpx} px @ 300 DPI</div>
            </div>
            <div style={styles.dimCard}>
              <div style={styles.dimLabel}>Spine Width</div>
              <div style={styles.dimValue}>{result.spineWidth}<span style={styles.dimUnit}>in</span></div>
            </div>
            <div style={styles.dimCard}>
              <div style={styles.dimLabel}>Bleed</div>
              <div style={styles.dimValue}>0.125<span style={styles.dimUnit}>in</span></div>
            </div>
          </div>
          <div style={{ ...styles.resultText, marginTop: "16px", fontSize: "13px", color: "#6B7A8D" }}>
            Safe zone inset: 0.25″ from all trim edges{"\n"}
            Front safe area starts at x = {result.frontSafeX}″{"\n"}
            Back safe area starts at x = {result.backSafeX}″{"\n"}
            Safe height: {result.safeH}″ · Safe width per side: {result.safeW}″
          </div>
        </div>
      )}
    </div>
  );
}

// ── Listing Writer ─────────────────────────────────────────────
function ListingWriter() {
  const [form, setForm] = useState({
    title: "", genre: "", logline: "", audience: "", tone: "", excerpt: "",
  });
  const [mode, setMode] = useState("blurb"); // blurb | keywords
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const generate = async () => {
    setLoading(true);
    setResult("");
    try {
      if (mode === "blurb") {
        const system = `You are an expert Amazon KDP book description writer. 
Write compelling, emotionally resonant book descriptions that sell. 
Use the hook → tension → stakes → CTA structure. 
Keep it under 400 words. No spoilers. No first-person author voice.
Output only the blurb text, nothing else.`;
        const user = `Title: ${form.title}
Genre: ${form.genre}
One-line premise: ${form.logline}
Target audience: ${form.audience}
Tone: ${form.tone}
${form.excerpt ? "\nSample pages from the book:\n---\n" + form.excerpt.slice(0, 3000) + "\n---" : ""}

Write the Amazon book description. If sample pages are provided, draw on the actual voice, characters, and details from those pages to make the description specific and authentic.`;
        const text = await callClaude(system, user);
        setResult(text);
      } else {
        const system = `You are an Amazon KDP keyword research expert.
Generate exactly 7 keyword phrases for Amazon KDP backend keywords.
Each phrase should be 2-5 words, highly searchable, and not include the book title.
Output as a numbered list, one per line, nothing else.`;
        const user = `Book title: ${form.title}
Genre: ${form.genre}
Premise: ${form.logline}
Target audience: ${form.audience}
${form.excerpt ? "Sample content provided: yes" : ""}

Generate 7 KDP backend keyword phrases.`;
        const text = await callClaude(system, user);
        setResult(text);
      }
    } catch (e) {
      setResult("Something went wrong. Please try again.");
    }
    setLoading(false);
  };

  const copy = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const ready = form.title && form.genre && form.logline;

  return (
    <div>
      <div style={styles.card}>
        <div style={styles.cardTitle}>Listing Writer</div>
        <div style={styles.cardDesc}>
          Turn rough notes about your book into a polished Amazon description
          and backend keywords that help readers find you.
        </div>

        <div style={{ display: "flex", gap: "8px", marginBottom: "20px" }}>
          {["blurb", "keywords"].map((m) => (
            <button
              key={m}
              onClick={() => { setMode(m); setResult(""); }}
              style={{
                ...( mode === m ? styles.btn : { ...styles.btnDisabled, background: "#1E2D3D", color: "#9AAABA" }),
                padding: "8px 18px",
                fontSize: "13px",
              }}
            >
              {m === "blurb" ? "Book Description" : "7 Keywords"}
            </button>
          ))}
        </div>

        <label style={styles.label}>Book Title *</label>
        <input style={styles.input} value={form.title} onChange={set("title")} placeholder="What We Carry" />

        <label style={styles.label}>Genre *</label>
        <input style={styles.input} value={form.genre} onChange={set("genre")} placeholder="Literary fiction / Family saga" />

        <label style={styles.label}>One-line premise *</label>
        <textarea style={styles.textarea} value={form.logline} onChange={set("logline")}
          placeholder="A multigenerational Telugu family story spanning three generations, centered on a cardamom tin passed from grandmother to granddaughter."
        />

        <div style={styles.row}>
          <div>
            <label style={styles.label}>Target audience</label>
            <input style={styles.input} value={form.audience} onChange={set("audience")} placeholder="Fans of literary diaspora fiction" />
          </div>
          <div>
            <label style={styles.label}>Tone</label>
            <input style={styles.input} value={form.tone} onChange={set("tone")} placeholder="Lyrical, emotional, hopeful" />
          </div>
        </div>

        <label style={styles.label}>
          Paste a chapter, synopsis, or sample pages
          <span style={{ color: "#6B7A8D", fontWeight: "400", marginLeft: "6px" }}>(optional but recommended)</span>
        </label>
        <textarea
          style={{ ...styles.textarea, minHeight: "140px" }}
          value={form.excerpt}
          onChange={set("excerpt")}
          placeholder="Paste your opening chapter, a key scene, or a synopsis here. Claude will draw on your actual writing — your characters' names, your voice, specific details — to write a description that truly reflects your book rather than a generic summary."
        />
        {form.excerpt && (
          <div style={{ fontFamily: "system-ui", fontSize: "12px", color: "#6B7A8D", marginTop: "-10px", marginBottom: "16px" }}>
            {form.excerpt.length.toLocaleString()} characters · {Math.min(form.excerpt.length, 3000).toLocaleString()} will be sent to Claude
            {form.excerpt.length > 3000 && <span style={{ color: "#C9A84C" }}> · trimmed to first 3,000</span>}
          </div>
        )}

        <button
          style={{ ...(ready && !loading ? styles.btn : styles.btnDisabled), opacity: loading ? 0.7 : 1 }}
          onClick={() => ready && !loading && generate()}
        >
          {loading
            ? <><span style={styles.spinner} />Generating…</>
            : mode === "blurb" ? "Write Description" : "Generate Keywords"
          }
        </button>
      </div>

      {result && (
        <div style={styles.resultBox}>
          <div style={styles.resultTitle}>
            {mode === "blurb" ? "Amazon Book Description" : "KDP Backend Keywords"}
          </div>
          <div style={styles.resultText}>{result}</div>
          <button style={styles.copyBtn} onClick={copy}>
            {copied ? "✓ Copied" : "Copy to clipboard"}
          </button>
        </div>
      )}
    </div>
  );
}

// ── Submission Coach ───────────────────────────────────────────
const CHECKLIST_ITEMS = [
  { id: 1, section: "Manuscript", text: "Interior PDF exported at 300 DPI or higher" },
  { id: 2, section: "Manuscript", text: "Fonts are embedded in the PDF" },
  { id: 3, section: "Manuscript", text: "Margins meet KDP minimums (0.25″ outer, 0.375–0.875″ gutter based on page count)" },
  { id: 4, section: "Manuscript", text: "No content in the gutter — text and images respect mirror margins" },
  { id: 5, section: "Manuscript", text: "Page numbers present and correctly positioned" },
  { id: 6, section: "Manuscript", text: "Chapter headings consistent throughout" },
  { id: 7, section: "Cover", text: "Cover canvas is correct size (use Cover Studio above)" },
  { id: 8, section: "Cover", text: "All text and critical art within the 0.25″ safe zone" },
  { id: 9, section: "Cover", text: "Back cover barcode area is clear (bottom-right, at least 2″ × 1.2″)" },
  { id: 10, section: "Cover", text: "Cover is a single flattened TIFF or PDF, no layers" },
  { id: 11, section: "Cover", text: "Cover resolution is 300 DPI" },
  { id: 12, section: "Cover", text: "Spine text is only included if spine width ≥ 0.25″" },
  { id: 13, section: "Listing", text: "Book title on cover matches exactly what was entered in KDP" },
  { id: 14, section: "Listing", text: "Author name matches KDP account name" },
  { id: 15, section: "Listing", text: "Book description written and reviewed" },
  { id: 16, section: "Listing", text: "2 BISAC categories selected" },
  { id: 17, section: "Listing", text: "7 backend keywords entered" },
  { id: 18, section: "Listing", text: "Pricing set for all enabled territories" },
  { id: 19, section: "Final", text: "Interior previewed in KDP previewer — no blank pages, no text cutoff" },
  { id: 20, section: "Final", text: "Cover previewed in KDP — spine text centered, no bleed artifacts" },
];

function SubmissionCoach() {
  const [checked, setChecked] = useState({});
  const toggle = (id) => setChecked((c) => ({ ...c, [id]: !c[id] }));
  const doneCount = Object.values(checked).filter(Boolean).length;
  const total = CHECKLIST_ITEMS.length;
  const pct = Math.round((doneCount / total) * 100);

  const sections = [...new Set(CHECKLIST_ITEMS.map((i) => i.section))];

  return (
    <div>
      <div style={styles.card}>
        <div style={styles.cardTitle}>Pre-Submission Checklist</div>
        <div style={styles.cardDesc}>
          Every item that KDP reviewers check before approving your book.
          Work through this before you hit Submit.
        </div>

        {/* Progress */}
        <div style={{ marginBottom: "24px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "8px" }}>
            <span style={{ fontFamily: "system-ui", fontSize: "13px", color: "#9AAABA" }}>
              {doneCount} of {total} complete
            </span>
            <span style={{ fontFamily: "monospace", fontSize: "13px", color: pct === 100 ? "#5CB85C" : "#C9A84C" }}>
              {pct}%
            </span>
          </div>
          <div style={{ background: "#0F1923", borderRadius: "4px", height: "6px", overflow: "hidden" }}>
            <div style={{
              width: `${pct}%`, height: "100%",
              background: pct === 100 ? "#5CB85C" : "#C9A84C",
              transition: "width 0.3s ease",
              borderRadius: "4px",
            }} />
          </div>
        </div>

        {sections.map((section) => (
          <div key={section} style={{ marginBottom: "20px" }}>
            <div style={{
              fontSize: "11px", fontFamily: "system-ui", color: "#C9A84C",
              textTransform: "uppercase", letterSpacing: "0.1em",
              fontWeight: "600", marginBottom: "8px",
            }}>
              {section}
            </div>
            <ul style={styles.checklist}>
              {CHECKLIST_ITEMS.filter((i) => i.section === section).map((item) => (
                <li
                  key={item.id}
                  style={styles.checkItem(checked[item.id])}
                  onClick={() => toggle(item.id)}
                >
                  <div style={styles.checkBox(checked[item.id])}>
                    {checked[item.id] && "✓"}
                  </div>
                  {item.text}
                </li>
              ))}
            </ul>
          </div>
        ))}

        {pct === 100 && (
          <div style={{
            background: "#0D2010", border: "1px solid #2D5A27",
            borderRadius: "6px", padding: "16px",
            fontFamily: "system-ui", fontSize: "14px", color: "#5CB85C",
            textAlign: "center", marginTop: "8px",
          }}>
            ✓ All checks passed — you're ready to submit to KDP
          </div>
        )}
      </div>
    </div>
  );
}


// ── Help Chat ──────────────────────────────────────────────────
const KDP_SYSTEM_PROMPT = `You are a friendly, expert KDP (Kindle Direct Publishing) support assistant built into PublishReady, a self-publishing tool. You help authors navigate Amazon KDP technical requirements, cover formatting, manuscript preparation, and listing optimization.

You have deep knowledge of:
- KDP cover dimensions: canvas size = (trim width x 2) + spine width + 0.25 inch bleed. Spine = pages x 0.002252 + 0.06 (white paper). Safe zone = 0.25 inch inset from all trim edges.
- KDP manuscript requirements: 300 DPI, embedded fonts, mirror margins (min 0.25 inch outer, gutter varies: 0-150 pages=0.375 inch, 151-300=0.5 inch, 301-500=0.625 inch, 501-700=0.75 inch, 700+=0.875 inch)
- KDP listing: 2 BISAC categories, 7 backend keywords, book description under 4000 characters
- Common rejection reasons and fixes
- Hardcover vs paperback differences
- KDP royalties (35% vs 70% threshold at $2.99-$9.99)
- ISBN requirements and KDP free ISBN

Keep answers concise, practical, and specific. Never make up KDP rules.`;

const SUGGESTED_QUESTIONS = [
  "Why did KDP reject my cover?",
  "How do I calculate my spine width?",
  "What is the 35% vs 70% royalty difference?",
  "How do I choose the right BISAC category?",
  "What margin size for 300 pages?",
  "Can I use my own ISBN?",
];

function HelpChat() {
  const [messages, setMessages] = useState([
    { role: "assistant", content: "Hi! I am your KDP support assistant. I know Amazon publishing rules inside and out — cover dimensions, manuscript requirements, royalties, rejections. What can I help you with?" },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  const sendMessage = async (text) => {
    const userText = text || input.trim();
    if (!userText || loading) return;
    setInput("");
    const newMessages = [...messages, { role: "user", content: userText }];
    setMessages(newMessages);
    setLoading(true);
    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          system: KDP_SYSTEM_PROMPT,
          messages: newMessages.slice(-8).map((m) => ({ role: m.role, content: m.content })),
        }),
      });
      const data = await response.json();
      const reply = data.content?.[0]?.text || "Sorry, could not get a response. Please try again.";
      setMessages((prev) => [...prev, { role: "assistant", content: reply }]);
    } catch {
      setMessages((prev) => [...prev, { role: "assistant", content: "Something went wrong. Please try again." }]);
    }
    setLoading(false);
  };

  const handleKey = (e) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  };

  return (
    <div>
      <div style={styles.card}>
        <div style={styles.cardTitle}>KDP Support Assistant</div>
        <div style={styles.cardDesc}>Ask anything about Amazon KDP — cover dimensions, manuscript rules, royalties, rejection fixes. Powered by Claude with KDP knowledge built in.</div>

        {messages.length === 1 && (
          <div style={{ marginBottom: "20px" }}>
            <div style={{ fontSize: "12px", fontFamily: "system-ui", color: "#6B7A8D", marginBottom: "10px", textTransform: "uppercase", letterSpacing: "0.08em" }}>Common questions</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
              {SUGGESTED_QUESTIONS.map((q) => (
                <button key={q} onClick={() => sendMessage(q)} style={{ background: "#1E2D3D", border: "1px solid #2A3545", borderRadius: "20px", padding: "6px 14px", color: "#C8D8E8", fontFamily: "system-ui, sans-serif", fontSize: "13px", cursor: "pointer" }}>
                  {q}
                </button>
              ))}
            </div>
          </div>
        )}

        <div style={{ background: "#0A1018", border: "1px solid #1E2D3D", borderRadius: "6px", padding: "16px", minHeight: "280px", maxHeight: "400px", overflowY: "auto", marginBottom: "12px", display: "flex", flexDirection: "column", gap: "14px" }}>
          {messages.map((msg, i) => (
            <div key={i} style={{ display: "flex", justifyContent: msg.role === "user" ? "flex-end" : "flex-start" }}>
              <div style={{ maxWidth: "80%", background: msg.role === "user" ? "#1E3A5A" : "#141F2B", border: `1px solid ${msg.role === "user" ? "#2A5580" : "#1E2D3D"}`, borderRadius: "10px", padding: "10px 14px", fontFamily: "system-ui, sans-serif", fontSize: "14px", color: "#C8D8E8", lineHeight: "1.6", whiteSpace: "pre-wrap" }}>
                {msg.role === "assistant" && (<div style={{ fontSize: "11px", color: "#C9A84C", marginBottom: "5px", fontWeight: "600", letterSpacing: "0.06em" }}>KDP ASSISTANT</div>)}
                {msg.content}
              </div>
            </div>
          ))}
          {loading && (
            <div style={{ display: "flex", justifyContent: "flex-start" }}>
              <div style={{ background: "#141F2B", border: "1px solid #1E2D3D", borderRadius: "10px", padding: "10px 14px" }}>
                <div style={{ fontSize: "11px", color: "#C9A84C", marginBottom: "5px", fontWeight: "600", letterSpacing: "0.06em" }}>KDP ASSISTANT</div>
                <span style={styles.spinner} /><span style={{ fontFamily: "system-ui", fontSize: "14px", color: "#6B7A8D" }}>Thinking...</span>
              </div>
            </div>
          )}
        </div>

        <div style={{ display: "flex", gap: "10px" }}>
          <textarea style={{ ...styles.textarea, marginBottom: 0, minHeight: "44px", maxHeight: "120px", flex: 1 }} placeholder="Ask a KDP question..." value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={handleKey} rows={1} />
          <button style={{ ...(input.trim() && !loading ? styles.btn : styles.btnDisabled), padding: "10px 18px", alignSelf: "flex-end" }} onClick={() => sendMessage()}>Send</button>
        </div>
        <div style={{ fontFamily: "system-ui", fontSize: "12px", color: "#6B7A8D", marginTop: "8px", display: "flex", justifyContent: "space-between" }}><span>Press Enter to send · Shift+Enter for new line</span><span style={{ color: messages.length > 7 ? "#C9A84C" : "#6B7A8D" }}>{Math.min(messages.length, 8)} of 8 in context{messages.length > 8 ? " · older messages trimmed" : ""}</span></div>
      </div>
    </div>
  );
}

// ── App shell ──────────────────────────────────────────────────
export default function PublishReady() {
  const [tab, setTab] = useState("cover");

  return (
    <div style={styles.root}>
      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
        input:focus, textarea:focus, select:focus {
          border-color: #C9A84C !important;
          box-shadow: 0 0 0 2px rgba(201,168,76,0.15);
        }
        button:hover:not(:disabled) { opacity: 0.85; }
      `}</style>

      <header style={styles.header}>
        <div style={styles.logo}>PublishReady</div>
        <div style={styles.tagline}>From manuscript to live listing — no rejections</div>
      </header>

      <nav style={styles.nav}>
        {TABS.map((t) => (
          <button key={t.id} style={styles.tab(tab === t.id)} onClick={() => setTab(t.id)}>
            {t.label}
          </button>
        ))}
      </nav>

      <main style={styles.main}>
        {tab === "cover" && <CoverStudio />}
        {tab === "listing" && <ListingWriter />}
        {tab === "checklist" && <SubmissionCoach />}
        {tab === "help" && <HelpChat />}
      </main>
    </div>
  );
}
