# PublishReady

**KDP Self-Publishing Assistant** — From manuscript to live Amazon listing, no rejections.

## Modules
- 📐 **Cover Studio** — Calculate exact KDP cover dimensions, spine width, bleed, and safe zones
- ✍️ **Listing Writer** — AI-powered Amazon book description and keyword generator
- ✅ **Submission Coach** — 20-item pre-submission checklist
- 💬 **Help** — AI support chatbot with KDP knowledge built in

---

## Running on Bolt (bolt.new)

1. Go to [bolt.new](https://bolt.new)
2. Click **"Import from zip"** and upload `publishready.zip`
3. Bolt installs dependencies and runs the app automatically

---

## Running locally

**Requirements:** Node.js 18+ installed (download at nodejs.org)

```bash
# Install dependencies
npm install

# Start the development server
npm run dev
```

Then open **http://localhost:5173** in your browser.

---

## Building for production (Vercel deployment)

```bash
npm run build
```

Upload the `dist/` folder to [Vercel](https://vercel.com) or connect your GitHub repo for automatic deployments.

---

## Powered by
- [Claude API](https://anthropic.com) — AI generation for listing writer and help chatbot
- [React](https://react.dev) + [Vite](https://vitejs.dev)
- Deploy on [Vercel](https://vercel.com) (free tier)
